/**
 * shenzhen-tour — 深圳本地游玩助手
 * 调用 weather + venues 数据库，生成动态游玩计划
 */

const fs = require('fs').promises;
const path = require('path');

// 假设 OpenClaw 提供的工具函数（实际由框架注入）
async function callTool(toolName, params) {
  // 此处为模拟调用；实际运行时由 OpenClaw 注入真实工具
  if (toolName === 'weather') {
    // 模拟返回深圳天气（真实环境会调用 weather skill）
    return {
      location: "深圳",
      temp: 22,
      condition: "多云",
      humidity: 65,
      windSpeed: 12,
      precipitation: 10,
      uvIndex: 5,
      feelsLike: 23,
      timestamp: new Date().toISOString()
    };
  }
  throw new Error(`Unknown tool: ${toolName}`);
}

async function loadVenues() {
  try {
    const data = await fs.readFile(path.join(__dirname, 'data', 'venues.json'), 'utf8');
    return JSON.parse(data).venues;
  } catch (e) {
    console.error('Failed to load venues:', e);
    return [];
  }
}

function filterVenuesByWeather(venues, weather) {
  const { condition, precipitation } = weather;
  const isRainy = precipitation > 30;
  const isSunny = condition.includes('晴');
  const isCloudy = condition.includes('云');

  let candidates = venues.filter(v => {
    if (isRainy && !v.tags.includes('indoor')) return false;
    if (isSunny && !v.tags.includes('outdoor') && !v.tags.includes('scenic')) return false;
    // 优先保留“任何天气”兼容项
    if (v.best_weather?.includes('任何天气')) return true;
    return v.best_weather?.some(w => w === condition || w === '多云' || w === '晴');
  });

  // 按类型去重：确保有 mall / scenic / cultural 各至少1个
  const byType = {};
  for (const v of candidates) {
    if (!byType[v.type]) byType[v.type] = v;
  }

  return Object.values(byType).slice(0, 4); // 最多4个
}

function generatePlan(recommended) {
  const items = [];
  if (recommended[0]) items.push(`1. 上午：${recommended[0].name} — ${recommended[0].description}`);
  if (recommended[1]) items.push(`2. 中午：${recommended[1].name} — ${recommended[1].description}`);
  if (recommended[2]) items.push(`3. 下午：${recommended[2].name} — ${recommended[2].description}`);
  if (recommended[3]) items.push(`4. 傍晚：${recommended[3].name} — ${recommended[3].description}`);

  return items.join('\n');
}

module.exports = async function shenzhenTour(query, context = {}) {
  try {
    // 1. 获取天气
    const weather = await callTool('weather', { city: '深圳' });
    
    // 2. 加载景点
    const venues = await loadVenues();
    
    // 3. 智能筛选
    const recommended = filterVenuesByWeather(venues, weather);
    
    // 4. 生成计划
    const plan = generatePlan(recommended);

    // 5. 构建响应
    const response = `
🌤️ 【今日深圳天气】  
- 温度: ${weather.temp}°C  
- 天气: ${weather.condition}  
- 湿度: ${weather.humidity}%  
- 风速: ${weather.windSpeed} km/h  
- 降水概率: ${weather.precipitation}%  
- 体感温度: ${weather.feelsLike}°C  

🎯 【推荐行程】  
${plan}

💡 小贴士：建议携带轻便外套；地铁覆盖广，推荐使用「深圳通」APP扫码乘车。
`;

    return {
      type: 'markdown',
      content: response,
      metadata: {
        skill: 'shenzhen-tour',
        weather: weather,
        recommendations: recommended.map(v => v.name)
      }
    };

  } catch (err) {
    return {
      type: 'text',
      content: `抱歉，深圳游玩助手暂时遇到问题：${err.message}\n请稍后重试。`
    };
  }
};